This is the main directory of the project.
